<?php

namespace App\Http\Livewire\Mail;

use Livewire\Component;

class IndexComponent extends Component
{
    public function render()
    {
        return view('livewire.mail.index-component');
    }
}

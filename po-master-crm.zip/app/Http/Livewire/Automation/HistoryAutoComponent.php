<?php

namespace App\Http\Livewire\Automation;

use Livewire\Component;

class HistoryAutoComponent extends Component
{
    public function render()
    {
        return view('livewire.automation.history-auto-component');
    }
}

<?php

namespace App\Http\Livewire\Automation;

use Livewire\Component;

class EditAutoComponent extends Component
{
    public function render()
    {
        return view('livewire.automation.edit-auto-component');
    }
}

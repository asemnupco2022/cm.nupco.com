<?php


namespace rifrocket\LaravelCms\Http\Livewire\AdminControllers\layouts;


use Livewire\Component;

class AdminNavBarComponent extends  Component
{

    public function render()
    {
        return view('LbsViews::livewire.AdminComponent.layouts.admin_nav');
    }
}

<?php


namespace rifrocket\LaravelCms\Http\Livewire\AdminControllers\AppSettingControllers;


use Livewire\Component;

class AppSettingComponent extends Component
{
    public function render()
    {
        return view('LbsViews::livewire.AdminComponent.AppSettingComponent.app_settings');
    }
}

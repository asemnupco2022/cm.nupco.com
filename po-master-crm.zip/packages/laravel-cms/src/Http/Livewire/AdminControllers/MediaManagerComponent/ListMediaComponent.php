<?php


namespace rifrocket\LaravelCms\Http\Livewire\AdminControllers\MediaManagerComponent;


use Livewire\Component;

class ListMediaComponent extends Component
{
    public function render()
    {
        return view('LbsViews::livewire.AdminComponent.MediaManagerComponent.list_media_manager');
    }
}

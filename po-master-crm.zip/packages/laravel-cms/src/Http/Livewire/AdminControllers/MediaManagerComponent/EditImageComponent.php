<?php


namespace rifrocket\LaravelCms\Http\Livewire\AdminControllers\MediaManagerComponent;


use Livewire\Component;

class EditImageComponent extends Component
{
    public function render()
    {

        return view('LbsViews::livewire.AdminComponent.MediaManagerComponent.edit_image_media_manager');
    }
}

<?php

namespace rifrocket\LaravelCms\Database\seeders;

use Illuminate\Database\Seeder;

class LbsMediaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

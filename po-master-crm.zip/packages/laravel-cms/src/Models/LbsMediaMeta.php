<?php

namespace rifrocket\LaravelCms\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LbsMediaMeta extends Model
{
    use HasFactory;
}

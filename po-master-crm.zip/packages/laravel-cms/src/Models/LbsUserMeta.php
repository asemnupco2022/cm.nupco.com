<?php

namespace rifrocket\LaravelCms\Models;


use rifrocket\LaravelCms\Models\ModelTraits\UniversalModelTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LbsUserMeta extends Model
{
    use UniversalModelTrait,HasFactory;
}

<?php
return [
    'name' => 'admin',
];

